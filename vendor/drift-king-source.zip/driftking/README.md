# 漂移之王 Drift King

A 60-second 3D arcade drift-scoring game (three.js + Rapier + Vite) with a global leaderboard.

- **Play**: W/↑ gas, S/↓ brake, A/D or ←/→ steer, Space handbrake, R reset. Gamepad: RT gas, LT brake, stick steer, A handbrake. Phones: on-screen buttons in landscape.
- **Scoring**: slip angle × duration builds the multiplier; glowing clip rings double points and add a bonus; hitting (or grinding) a wall wipes the running drift. Heat rises at 20/40/50 s.
- **Today's Challenge**: the UTC date seeds weather/time (night, rain, dusk, fog, dawn) and clip placement, so everyone drives the same run.
- **Online**: nickname-only guest identity, Today + All-time boards, rank and "beat X%" on the results screen, share card with QR code, challenge links (`?vs=`) that show a target score.

## Layout

| Path | Contents |
| --- | --- |
| `src/game/` | track spline, car model, drift rules, daily seed, world, FX, camera, autopilot |
| `src/online/` | leaderboard client, challenge links, share card |
| `src/ui/`, `src/styles/` | HTML/CSS game UI |
| `server/` | leaderboard API (Node + MySQL), anti-cheat in `drift-rules.mjs`, migrations |
| `game-backend-contract.json` | hybrid deploy contract (must match config routes) |

## Checks

```sh
pnpm test            # unit tests (rules, server parity, daily seed, links, i18n)
pnpm build           # typecheck + bundle + size budget
node scripts/smoke.mjs                   # headless end-to-end smoke (needs dist/)
node scripts/bottrace.mjs --runs 3       # balance: autopilot runs on the dev server
node scripts/api-test.mjs                # protocol test against a LOCAL throwaway DB only
```

Tuning lives in `src/game/config.ts`; the server's plausibility bound in `server/drift-rules.mjs` mirrors it (a unit test enforces parity).
